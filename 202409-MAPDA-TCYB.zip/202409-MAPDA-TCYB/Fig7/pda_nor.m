lenn=400;
for i=1:lenn
   thd(i)=3.1; 
end
for i=1:lenn
   t(i)=i*0.02; 
end

Data = importdata('PDA_Nor001.txt');
len=length(Data.data(:,1));
pos=Data.data(:,1);
posa=Data.data(:,2);
ang=Data.data(:,3);
anga=Data.data(:,4);
x=[pos,ang,posa,anga]';
for i=1:len
   nor_x(i)=norm(x(:,i),2); 
end
maxnorx(1)=max(nor_x);

Fonts=18;
k=1:lenn;
fig1=figure(1);
set(fig1, 'Position', [0 0 1000 350]); 
set(fig1, 'PaperSize', [29.7000 21.0000]); 
set(fig1,'PaperPosition',[1 1 21 7]);
plot(t(k),pos(k),'b','LineWidth',2);hold on;

fig2=figure(2);
set(fig2, 'Position', [0 0 1000 350]); 
set(fig2, 'PaperSize', [29.7000 21.0000]); 
set(fig2,'PaperPosition',[1 1 21 7]);
plot(t(k),ang(k),'b','LineWidth',2);hold on;

fig3=figure(3);
set(fig3, 'Position', [0 0 1000 350]); 
set(fig3, 'PaperSize', [29.7000 21.0000]); 
set(fig3,'PaperPosition',[1 1 21 7]);
plot(t(k),posa(k),'b','LineWidth',2);hold on;

fig4=figure(4);
set(fig4, 'Position', [0 0 1000 350]); 
set(fig4, 'PaperSize', [29.7000 21.0000]); 
set(fig4,'PaperPosition',[1 1 21 7]);
plot(t(k),anga(k),'b','LineWidth',2);hold on;

fig5=figure(5);
set(fig5, 'Position', [0 0 1000 350]); 
set(fig5, 'PaperSize', [29.7000 21.0000]); 
set(fig5,'PaperPosition',[1 1 21 7]);
plot(t(k),nor_x(k),'b','LineWidth',2);hold on;

Data = importdata('PDA_Nor002.txt');
len=length(Data.data(:,1));
pos=Data.data(:,1);
posa=Data.data(:,2);
ang=Data.data(:,3);
anga=Data.data(:,4);
x=[pos,ang,posa,anga]';
for i=1:len
   nor_x(i)=norm(x(:,i),2); 
end
maxnorx(2)=max(nor_x);

k=1:lenn;
fig1=figure(1);
set(fig1, 'Position', [0 0 1000 350]); 
set(fig1, 'PaperSize', [29.7000 21.0000]); 
set(fig1,'PaperPosition',[1 1 21 7]);
plot(t(k),pos(k),'--r','LineWidth',2);hold on;

fig2=figure(2);
set(fig2, 'Position', [0 0 1000 350]); 
set(fig2, 'PaperSize', [29.7000 21.0000]); 
set(fig2,'PaperPosition',[1 1 21 7]);
plot(t(k),ang(k),'--r','LineWidth',2);hold on;

fig3=figure(3);
set(fig3, 'Position', [0 0 1000 350]); 
set(fig3, 'PaperSize', [29.7000 21.0000]); 
set(fig3,'PaperPosition',[1 1 21 7]);
plot(t(k),posa(k),'--r','LineWidth',2);hold on;

fig4=figure(4);
set(fig4, 'Position', [0 0 1000 350]); 
set(fig4, 'PaperSize', [29.7000 21.0000]); 
set(fig4,'PaperPosition',[1 1 21 7]);
plot(t(k),anga(k),'--r','LineWidth',2);hold on;

fig5=figure(5);
set(fig5, 'Position', [0 0 1000 350]); 
set(fig5, 'PaperSize', [29.7000 21.0000]); 
set(fig5,'PaperPosition',[1 1 21 7]);
plot(t(k),nor_x(k),'--r','LineWidth',2);hold on;

Data = importdata('PDA_Nor003.txt');
len=length(Data.data(:,1));
pos=Data.data(:,1);
posa=Data.data(:,2);
ang=Data.data(:,3);
anga=Data.data(:,4);
x=[pos,ang,posa,anga]';
for i=1:len
   nor_x(i)=norm(x(:,i),2); 
end
maxnorx(3)=max(nor_x);

k=1:lenn;
fig1=figure(1);
set(fig1, 'Position', [0 0 1000 350]); 
set(fig1, 'PaperSize', [29.7000 21.0000]); 
set(fig1,'PaperPosition',[1 1 21 7]);
plot(t(k),pos(k),'--g','LineWidth',2);hold on;

fig2=figure(2);
set(fig2, 'Position', [0 0 1000 350]); 
set(fig2, 'PaperSize', [29.7000 21.0000]); 
set(fig2,'PaperPosition',[1 1 21 7]);
plot(t(k),ang(k),'--g','LineWidth',2);hold on;

fig3=figure(3);
set(fig3, 'Position', [0 0 1000 350]); 
set(fig3, 'PaperSize', [29.7000 21.0000]); 
set(fig3,'PaperPosition',[1 1 21 7]);
plot(t(k),posa(k),'--g','LineWidth',2);hold on;

fig4=figure(4);
set(fig4, 'Position', [0 0 1000 350]); 
set(fig4, 'PaperSize', [29.7000 21.0000]); 
set(fig4,'PaperPosition',[1 1 21 7]);
plot(t(k),anga(k),'--g','LineWidth',2);hold on;

fig5=figure(5);
set(fig5, 'Position', [0 0 1000 350]); 
set(fig5, 'PaperSize', [29.7000 21.0000]); 
set(fig5,'PaperPosition',[1 1 21 7]);
plot(t(k),nor_x(k),'--g','LineWidth',2);hold on;

Data = importdata('PDA_Nor004.txt');
len=length(Data.data(:,1));
pos=Data.data(:,1);
posa=Data.data(:,2);
ang=Data.data(:,3);
anga=Data.data(:,4);
x=[pos,ang,posa,anga]';
for i=1:len
   nor_x(i)=norm(x(:,i),2); 
end
maxnorx(4)=max(nor_x);

k=1:lenn;
fig1=figure(1);
set(fig1, 'Position', [0 0 1000 350]); 
set(fig1, 'PaperSize', [29.7000 21.0000]); 
set(fig1,'PaperPosition',[1 1 21 7]);
plot(t(k),pos(k),':c','LineWidth',2);hold on;

fig2=figure(2);
set(fig2, 'Position', [0 0 1000 350]); 
set(fig2, 'PaperSize', [29.7000 21.0000]); 
set(fig2,'PaperPosition',[1 1 21 7]);
plot(t(k),ang(k),':c','LineWidth',2);hold on;

fig3=figure(3);
set(fig3, 'Position', [0 0 1000 350]); 
set(fig3, 'PaperSize', [29.7000 21.0000]); 
set(fig3,'PaperPosition',[1 1 21 7]);
plot(t(k),posa(k),':c','LineWidth',2);hold on;

fig4=figure(4);
set(fig4, 'Position', [0 0 1000 350]); 
set(fig4, 'PaperSize', [29.7000 21.0000]); 
set(fig4,'PaperPosition',[1 1 21 7]);
plot(t(k),anga(k),':c','LineWidth',2);hold on;

fig5=figure(5);
set(fig5, 'Position', [0 0 1000 350]); 
set(fig5, 'PaperSize', [29.7000 21.0000]); 
set(fig5,'PaperPosition',[1 1 21 7]);
plot(t(k),nor_x(k),':c','LineWidth',2);hold on;

Data = importdata('PDA_Nor005.txt');
len=length(Data.data(:,1));
pos=Data.data(:,1);
posa=Data.data(:,2);
ang=Data.data(:,3);
anga=Data.data(:,4);
x=[pos,ang,posa,anga]';
for i=1:len
   nor_x(i)=norm(x(:,i),2); 
end
maxnorx(5)=max(nor_x);

k=1:lenn;
fig1=figure(1);
set(fig1, 'Position', [0 0 1000 350]); 
set(fig1, 'PaperSize', [29.7000 21.0000]); 
set(fig1,'PaperPosition',[1 1 21 7]);
plot(t(k),pos(k),':m','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\alpha(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');

fig2=figure(2);
set(fig2, 'Position', [0 0 1000 350]); 
set(fig2, 'PaperSize', [29.7000 21.0000]); 
set(fig2,'PaperPosition',[1 1 21 7]);
plot(t(k),ang(k),':m','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\theta(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');

fig3=figure(3);
set(fig3, 'Position', [0 0 1000 350]); 
set(fig3, 'PaperSize', [29.7000 21.0000]); 
set(fig3,'PaperPosition',[1 1 21 7]);
plot(t(k),posa(k),':m','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\dot \alpha(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');

fig4=figure(4);
set(fig4, 'Position', [0 0 1000 350]); 
set(fig4, 'PaperSize', [29.7000 21.0000]); 
set(fig4,'PaperPosition',[1 1 21 7]);
plot(t(k),anga(k),':m','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\dot \theta(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');

fig5=figure(5);
set(fig5, 'Position', [0 0 1000 350]);
set(fig5, 'PaperSize', [29.7000 21.0000]); 
set(fig5,'PaperPosition',[1 1 21 7]);
plot(t(k),nor_x(k),':m','LineWidth',2);hold on;
plot(t(k),thd(k),'-.k','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\left\| {{x_a}(t)} \right\|$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');

Data = importdata('PDA_Nor006.txt');
len=length(Data.data(:,1));
pos=Data.data(:,1);
posa=Data.data(:,2);
ang=Data.data(:,3);
anga=Data.data(:,4);
x=[pos,ang,posa,anga]';
for i=1:len
   nor_x(i)=norm(x(:,i),2); 
end
maxnorx(6)=max(nor_x);

k=1:lenn;
fig1=figure(1);
set(fig1, 'Position', [0 0 1000 350]); 
set(fig1, 'PaperSize', [29.7000 21.0000]); 
set(fig1,'PaperPosition',[1 1 21 7]);
plot(t(k),pos(k),':y','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\alpha(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
saveas(fig1,'nor_pos','pdf');

fig2=figure(2);
set(fig2, 'Position', [0 0 1000 350]); 
set(fig2, 'PaperSize', [29.7000 21.0000]); 
set(fig2,'PaperPosition',[1 1 21 7]);
plot(t(k),ang(k),':y','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\theta(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
saveas(fig2,'nor_ang','pdf');

fig3=figure(3);
set(fig3, 'Position', [0 0 1000 350]); 
set(fig3, 'PaperSize', [29.7000 21.0000]); 
set(fig3,'PaperPosition',[1 1 21 7]);
plot(t(k),posa(k),':y','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\dot \alpha(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
saveas(fig3,'nor_dpos','pdf');

fig4=figure(4);
set(fig4, 'Position', [0 0 1000 350]); 
set(fig4, 'PaperSize', [29.7000 21.0000]); 
set(fig4,'PaperPosition',[1 1 21 7]);
plot(t(k),anga(k),':y','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\dot \theta(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
saveas(fig4,'nor_dang','pdf');

fig5=figure(5);
set(fig5, 'Position', [0 0 1000 350]);
set(fig5, 'PaperSize', [29.7000 21.0000]); 
set(fig5,'PaperPosition',[1 1 21 7]);
plot(t(k),nor_x(k),':y','LineWidth',2);hold on;
plot(t(k),thd(k),'-.k','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\left\| {{x_a}(t)} \right\|$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
saveas(fig5,'nor_dec','pdf');