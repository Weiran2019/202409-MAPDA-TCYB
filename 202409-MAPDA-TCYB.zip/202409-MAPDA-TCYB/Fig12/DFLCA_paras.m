Data = importdata('PDA_Nor001.txt');
len=length(Data.data(:,1));
pos=Data.data(:,1);
posa=Data.data(:,2);
ang=Data.data(:,3);
anga=Data.data(:,4);
x=[pos,ang,posa,anga]';
K=[3.7569,-29.6225,4.0648,-5.4563];
u=zeros(1,len);
for i=1:len
   u(i)=K*x(:,i);
end
N=len-199;
Y=x(:,1:N);
Z=[u(1,1:N);x(:,1:N)];
for i=2:200
    Z=[Z;u(1,i:N+i-1);x(:,i:N+i-1)];
end
E0=Y*pinv(Z);
Ec=cell(1,199);
for i=1:199
    Ec{i}=[zeros(4,5*i),E0(:,1:(1000-5*i))];
end
Ga0=E0;
Gac=cell(1,199);
Gac{1}=Ec{1}+E0(:,997:1000)*Ga0;
for i=2:199
   Gac{i}=Ec{i}+E0(:,(1000-5*(i-1)-3):(1000-5*(i-1)))*Ga0;
   for j=1:i-1
       Gac{i}=Gac{i}+E0(:,(1000-5*(i-j-1)-3):(1000-5*(i-j-1)))*Gac{j};
   end
end
Lac=cell(1,200);
Lac{1}=E0(:,996);
for i=2:199
   Lac{i}=E0(:,1000-5*(i-1)-4);
   for j=1:i-1
      Lac{i}=Lac{i}+E0(:,(1000-5*(i-j-1)-3):(1000-5*(i-j-1)))*Lac{j};
   end
end
Ga=Gac{1};
for i=2:199
   Ga=[Ga;Gac{i}]; 
end
Latc=cell(1,199);%%�洢ÿһ��
Latc{1}=[Lac{1}];
for i=2:199
   Latc{1}=[Latc{1};Lac{i}]; 
end
for i=2:199
   Latc{i}=zeros(4*(i-1),1);
   for j=1:(200-i)
      Latc{i}=[Latc{i};Lac{j}]; 
   end
end
La=Latc{1};
for i=2:199
   La=[La,Latc{i}]; 
end
Sua=eye(199,199);
for i=2:199
   Sua(i,i-1)=-1; 
end
Suz=zeros(199,1000);
Suz(1,996)=1;
ratt=[0.4;0.9;0;0];
for i=2:199
   ratt=[ratt;[0.4;0.9;0;0]]; 
end
z=[u(1,1);x(:,1)];
for i=2:200
   z=[z;[u(1,i);x(:,i)]];
end
uatt=inv(La'*La+Sua'*Sua)*(La'*(ratt-Ga*z)+Sua'*Suz*z);
yatt=[Ga0;Ga]*z+[zeros(4,199);La]*uatt;
fid=fopen('yatt.txt','w');
for i=1:800
    fprintf(fid,'%f\n',yatt(i,1)); 
end
fclose(fid);
%yattT=yatt';