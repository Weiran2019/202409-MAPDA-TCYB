Data1 = importdata('PDA2_aam_FaI_Z10000.txt');
len1=length(Data1.data(:,1));
x1=[Data1.data(:,1),Data1.data(:,2),Data1.data(:,3),Data1.data(:,4)]';
xa1=[Data1.data(:,5),Data1.data(:,6),Data1.data(:,7),Data1.data(:,8)]';

Data21 = importdata('TLCA.txt');
len2=length(Data21.data(:,1));
x2=[Data21.data(:,1),Data21.data(:,3),Data21.data(:,2),Data21.data(:,4)]';
Data22 = importdata('PDA_Nor001.txt');
xa2=[Data22.data(:,1),Data22.data(:,3),Data22.data(:,2),Data22.data(:,4)]';

Data3 = importdata('DFLCA2.txt');
len3=length(Data3.data(:,1));
x3=[Data3.data(:,1),Data3.data(:,2),Data3.data(:,3),Data3.data(:,4)]';
xa3=[Data3.data(:,5),Data3.data(:,6),Data3.data(:,7),Data3.data(:,8)]';

for i=1:len1
   t1(i)=i*0.02; 
end
for i=1:len2
   t2(i)=i*0.02; 
end
for i=1:len3
   t3(i)=i*0.02; 
end

for i=1:len1
   thd(i)=3.1;
end

for i=1:len1
   nor_xa1(i)=norm(xa1(:,i),2); 
end
for i=1:len2
   nor_x2(i)=norm(x2(:,i),2);
   nor_xa2(i)=norm(xa2(:,i),2); 
end
for i=1:len3
   nor_xa3(i)=norm(xa3(:,i),2); 
end

Fonts=18;
fig1=figure(1);
set(fig1, 'Position', [0 0 1000 350]); 
set(fig1, 'PaperSize', [29.7000 21.0000]); 
set(fig1,'PaperPosition',[1 1 21 7]);
plot(t1(1:len1),x1(1,1:len1),'r','LineWidth',2);hold on;
plot(t2(1:len2),x2(1,1:len2),'-.g','LineWidth',2);hold on;
plot(t3(1:len3),x3(1,1:len3),'--','LineWidth',2,'Color',[0.63 0.13 0.94]);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\alpha(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
t11=text(t1(len1),x1(1,len1),'OFF');
set(t11,'Interpreter','latex','FontSize',Fonts);
t12=text(t2(len2),x2(1,len2),'OFF');
set(t12,'Interpreter','latex','FontSize',Fonts);
t13=text(t3(len3),x3(1,len3),'OFF');
set(t13,'Interpreter','latex','FontSize',Fonts);
saveas(fig1,'three_pos','pdf');

fig2=figure(2);
set(fig2, 'Position', [0 0 1000 350]); 
set(fig2, 'PaperSize', [29.7000 21.0000]); 
set(fig2,'PaperPosition',[1 1 21 7]);
plot(t1(1:len1),x1(2,1:len1),'r','LineWidth',2);hold on;
plot(t2(1:len2),x2(2,1:len2),'-.g','LineWidth',2);hold on;
plot(t3(1:len3),x3(2,1:len3),'--','LineWidth',2,'Color',[0.63 0.13 0.94]);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\theta(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
% t11=text(t1(len1),x1(2,len1),'OFF');
% set(t11,'Interpreter','latex','FontSize',Fonts);
t12=text(t2(len2),x2(2,len2),'OFF');
set(t12,'Interpreter','latex','FontSize',Fonts);
t13=text(t3(len3),x3(2,len3),'OFF');
set(t13,'Interpreter','latex','FontSize',Fonts);
saveas(fig2,'three_ang','pdf');

fig3=figure(3);
set(fig3, 'Position', [0 0 1000 350]); 
set(fig3, 'PaperSize', [29.7000 21.0000]); 
set(fig3,'PaperPosition',[1 1 21 7]);
plot(t1(1:len1),x1(3,1:len1),'r','LineWidth',2);hold on;
plot(t2(1:len2),x2(3,1:len2),'-.g','LineWidth',2);hold on;
plot(t3(1:len3),x3(3,1:len3),'--','LineWidth',2,'Color',[0.63 0.13 0.94]);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\dot \alpha(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
t11=text(t1(len1),x1(3,len1),'OFF');
set(t11,'Interpreter','latex','FontSize',Fonts);
t12=text(t2(len2),x2(3,len2),'OFF');
set(t12,'Interpreter','latex','FontSize',Fonts);
t13=text(t3(len3),x3(3,len3),'OFF');
set(t13,'Interpreter','latex','FontSize',Fonts);
saveas(fig3,'three_dpos','pdf');

fig4=figure(4);
set(fig4, 'Position', [0 0 1000 350]); 
set(fig4, 'PaperSize', [29.7000 21.0000]); 
set(fig4,'PaperPosition',[1 1 21 7]);
plot(t1(1:len1),x1(4,1:len1),'r','LineWidth',2);hold on;
plot(t2(1:len2),x2(4,1:len2),'-.g','LineWidth',2);hold on;
plot(t3(1:len3),x3(4,1:len3),'--','LineWidth',2,'Color',[0.63 0.13 0.94]);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\dot \theta(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
t11=text(t1(len1),x1(4,len1),'OFF');
set(t11,'Interpreter','latex','FontSize',Fonts);
t12=text(t2(len2),x2(4,len2),'OFF');
set(t12,'Interpreter','latex','FontSize',Fonts);
t13=text(t3(len3),x3(4,len3),'OFF');
set(t13,'Interpreter','latex','FontSize',Fonts);
saveas(fig4,'three_dang','pdf');

fig5=figure(5);
set(fig5, 'Position', [0 0 1000 350]); 
set(fig5, 'PaperSize', [29.7000 21.0000]); 
set(fig5,'PaperPosition',[1 1 21 7]);
plot(t1(1:len1),nor_xa1(1:len1),'r','LineWidth',2);hold on;
plot(t2(1:len2),nor_xa2(1:len2),'-.g','LineWidth',2);hold on;
plot(t3(1:len3),nor_xa3(1:len3),'--','LineWidth',2,'Color',[0.63 0.13 0.94]);hold on;
plot(t2(1:len2),nor_x2(1:len2),'-.b','LineWidth',2);hold on;
plot(t1(1:len1),thd(1:len1),'-.k','LineWidth',2);hold on;
ylim([0 25]);
le11=xlabel('$t/s$');
le12=ylabel('$\left\| {{x_a}(t)} \right\|$');
%t21=text(t1(len1-20),6,'94.2%,500','FontSize',18);
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
h=axes('position',[0.4 0.65 0.2 0.2]);
axis(h);
plot(t1(1:22),nor_xa1(1:22),'r','LineWidth',2);hold on;
plot(t2(1:22),nor_xa2(1:22),'-.g','LineWidth',2);hold on;
plot(t3(1:22),nor_xa3(1:22),'--','LineWidth',2,'Color',[0.63 0.13 0.94]);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\left\| {{x_a}(t)} \right\|$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
saveas(fig5,'three_dec','pdf');