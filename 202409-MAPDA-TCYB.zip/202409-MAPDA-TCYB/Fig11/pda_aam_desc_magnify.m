Data = importdata('PDA_aam21.txt');
len=length(Data.data(:,1));
x1=Data.data(:,1);
x2=Data.data(:,2);
x3=Data.data(:,3);
x4=Data.data(:,4);
xa1=Data.data(:,5);
xa2=Data.data(:,6);
xa3=Data.data(:,7);
xa4=Data.data(:,8);
xa=[xa1,xa2,xa3,xa4]';
for i=1:len
   nor_xa(i)=norm(xa(:,i),2); 
end
for i=1:len
   t(i)=i*0.02; 
end
for i=1:len
   thd(i)=1.6; 
end

Fonts=18;
fig6=figure(6);
set(fig6, 'Position', [0 0 1000 350]); 
set(fig6, 'PaperSize', [29.7000 21.0000]); 
set(fig6,'PaperPosition',[1 1 21 7]);
plot(t(300:len),nor_xa(300:len),'r','LineWidth',2);hold on;
plot(t(300:len),thd(300:len),'-.k','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\left\|{x_a(t)}\right\|$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
saveas(fig6,'aam_d_dec_mag','pdf');