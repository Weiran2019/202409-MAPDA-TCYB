Data = importdata('PDA_aam22.txt');
len=length(Data.data(:,1));
x1=Data.data(:,1);
x2=Data.data(:,2);
x3=Data.data(:,3);
x4=Data.data(:,4);
xa1=Data.data(:,5);
xa2=Data.data(:,6);
xa3=Data.data(:,7);
xa4=Data.data(:,8);
xa=[xa1,xa2,xa3,xa4]';
for i=1:len
   nor_xa(i)=norm(xa(:,i),2); 
end
for i=1:len
   t(i)=i*0.02; 
end
for i=1:len
   thd(i)=1.6; 
end

Fonts=18;
k=1:len;
fig1=figure(1);
set(fig1, 'Position', [0 0 1000 350]); 
set(fig1, 'PaperSize', [29.7000 21.0000]); 
set(fig1,'PaperPosition',[1 1 21 7]);
plot(t(k),x1(k),'r','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\alpha(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
t21=text(t(len),x1(len),'OFF');
set(t21,'Interpreter','latex','FontSize',Fonts);

fig2=figure(2);
set(fig2, 'Position', [0 0 1000 350]); 
set(fig2, 'PaperSize', [29.7000 21.0000]); 
set(fig2,'PaperPosition',[1 1 21 7]);
plot(t(k),x2(k),'r','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\theta(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
t21=text(t(len),x2(len),'OFF');
set(t21,'Interpreter','latex','FontSize',Fonts);

fig3=figure(3);
set(fig3, 'Position', [0 0 1000 350]); 
set(fig3, 'PaperSize', [29.7000 21.0000]); 
set(fig3,'PaperPosition',[1 1 21 7]);
plot(t(k),x3(k),'r','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\dot \alpha(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
t21=text(t(len),x3(len),'OFF');
set(t21,'Interpreter','latex','FontSize',Fonts);

fig4=figure(4);
set(fig4, 'Position', [0 0 1000 350]); 
set(fig4, 'PaperSize', [29.7000 21.0000]); 
set(fig4,'PaperPosition',[1 1 21 7]);
plot(t(k),x4(k),'r','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\dot \theta(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
t21=text(t(len),x4(len)-1.2,'OFF');
set(t21,'Interpreter','latex','FontSize',Fonts);

fig5=figure(5);
set(fig5, 'Position', [0 0 1000 350]); 
set(fig5, 'PaperSize', [29.7000 21.0000]); 
set(fig5,'PaperPosition',[1 1 21 7]);
plot(t(k),nor_xa(k),'r','LineWidth',2);hold on;
plot(t(k),thd(k),'-.k','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\left\| {{x_a}(t)} \right\|$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');

Data = importdata('PDA_pam_r.txt');
len=length(Data.data(:,1));
x1=Data.data(:,1);
x2=Data.data(:,2);
x3=Data.data(:,3);
x4=Data.data(:,4);
xa1=Data.data(:,5);
xa2=Data.data(:,6);
xa3=Data.data(:,7);
xa4=Data.data(:,8);
xa=[xa1,xa2,xa3,xa4]';
for i=1:len
   nor_xa(i)=norm(xa(:,i),2); 
end
for i=1:len
   t(i)=i*0.02; 
end
for i=1:len
   thd(i)=1.6; 
end

Fonts=18;
k=1:len;
fig1=figure(1);
set(fig1, 'Position', [0 0 1000 350]); 
set(fig1, 'PaperSize', [29.7000 21.0000]); 
set(fig1,'PaperPosition',[1 1 21 7]);
plot([6,6],[-0.5,0.25],':g','LineWidth',2);hold on;
plot(t(k),x1(k),':b','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\alpha(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
t21=text(t(len-30),x1(len),'OFF');
set(t21,'Interpreter','latex','FontSize',Fonts);
saveas(fig1,'aam_c_pos','pdf');

fig2=figure(2);
set(fig2, 'Position', [0 0 1000 350]); 
set(fig2, 'PaperSize', [29.7000 21.0000]); 
set(fig2,'PaperPosition',[1 1 21 7]);
plot([6,6],[-0.5,0.5],':g','LineWidth',2);hold on;
plot(t(k),x2(k),':b','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\theta(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
t21=text(t(len-30),x2(len),'OFF');
set(t21,'Interpreter','latex','FontSize',Fonts);
saveas(fig2,'aam_c_ang','pdf');

fig3=figure(3);
set(fig3, 'Position', [0 0 1000 350]); 
set(fig3, 'PaperSize', [29.7000 21.0000]); 
set(fig3,'PaperPosition',[1 1 21 7]);
plot([6,6],[-1,1],':g','LineWidth',2);hold on;
plot(t(k),x3(k),':b','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\dot \alpha(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
t21=text(t(len-30),x3(len),'OFF');
set(t21,'Interpreter','latex','FontSize',Fonts);
saveas(fig3,'aam_c_dpos','pdf');

fig4=figure(4);
set(fig4, 'Position', [0 0 1000 350]); 
set(fig4, 'PaperSize', [29.7000 21.0000]); 
set(fig4,'PaperPosition',[1 1 21 7]);
plot([6,6],[-5,2.5],':g','LineWidth',2);hold on;
plot(t(k),x4(k),':b','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\dot \theta(t)$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
t21=text(t(len-40),x4(len-1),'OFF');
set(t21,'Interpreter','latex','FontSize',Fonts);
saveas(fig4,'aam_c_dang','pdf');

fig5=figure(5);
set(fig5, 'Position', [0 0 1000 350]); 
set(fig5, 'PaperSize', [29.7000 21.0000]); 
set(fig5,'PaperPosition',[1 1 21 7]);
plot([6,6],[0,2],':g','LineWidth',2);hold on;
plot(t(k),nor_xa(k),':b','LineWidth',2);hold on;
plot(t(k),thd(k),'-.k','LineWidth',2);hold on;
le11=xlabel('$t/s$');
le12=ylabel('$\left\| {{x_a}(t)} \right\|$');
set(gca,'FontSize',Fonts);
set(le11,'Interpreter','latex');
set(le12,'Interpreter','latex');
saveas(fig5,'aam_c_dec','pdf');